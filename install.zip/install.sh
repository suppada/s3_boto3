#!/bin/bash

set -xv

#install and upgrade
pip3 install --upgrade pip
pip3 install --upgrade awscli